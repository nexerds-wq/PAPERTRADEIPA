# Nexer Paper Trader

Fake-money-only iPhone paper trading app built with SwiftUI.

- Starts every new user with $10,000 fake cash.
- Uses public Yahoo Finance chart endpoints for market prices and OHLC candles.
- Supports stocks, ETFs, crypto, and forex symbols.
- Market, limit, stop, and take-profit style paper orders are simulated locally.
- No brokerage connection and no real-money trading code is included.
- RSI, MACD, EMA, SMA and candlestick pattern analysis are calculated on-device.

Open `NexerPaperTrader.xcodeproj` in Xcode, choose an iPhone target, then build/run. For SideStore, archive/sign the app using your normal sideloading workflow.

> Market-data availability depends on the third-party public endpoint and may be delayed or unavailable. This app is for education/paper trading only.
